/////////////////////////////////////////////////////////////////////////////
//
// (c) Copyright 2000-2016 CodeMachine Incorporated. All rights Reserved.
// Developed by CodeMachine Incorporated. (http://www.codemachine.com)
//
/////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4201)

#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <winternl.h>

#define SERVICES_KEY_A "\\REGISTRY\\MACHINE\\System\\CurrentControlSet\\Services"
#define SE_LOAD_DRIVER_PRIVILEGE            (10)

ULONG EnablePrivilege ( ULONG Privilege );

typedef NTSTATUS 
( *PNT_LOAD_DRIVER ) (
    PUNICODE_STRING DriverServiceName );

typedef NTSTATUS 
( *PNT_UNLOAD_DRIVER ) (
    PUNICODE_STRING DriverServiceName );

VOID LoadUnloadDriver ( PCHAR ServiceName, BOOL LoadOrUnload )
{
    HMODULE NtDll = NULL;
    PNT_LOAD_DRIVER NtLoadDriverX = NULL;
    PNT_UNLOAD_DRIVER NtUnloadDriverX = NULL;
    UNICODE_STRING ServicePathU = {0};
    NTSTATUS Status;
    ULONG Result;

    if ( ( NtDll = GetModuleHandle ( "ntdll.dll" ) ) == NULL ) {
        printf ( "[-] GetModuleHandle(ntdll.dll) : FAIL=0x%08x\n", GetLastError() );
        goto Exit;
    }

    if ( ( NtLoadDriverX = (PNT_LOAD_DRIVER)GetProcAddress ( 
            NtDll, "NtLoadDriver" ) ) == NULL ) {
        printf ( "[-] GetProcAddress(NtLoadDriver) : FAIL=0x%08x\n", GetLastError() );
        goto Exit;
    }

    if ( ( NtUnloadDriverX = (PNT_UNLOAD_DRIVER)GetProcAddress ( 
            NtDll, "NtUnloadDriver" ) ) == NULL ) {
        printf ( "[-] GetProcAddress(NtUnloadDriver) : FAIL=0x%08x\n", GetLastError() );
        goto Exit;
    }

    ServicePathU.MaximumLength =
        (USHORT) ( strlen(SERVICES_KEY_A) + strlen(ServiceName) + 2 ) * sizeof(WCHAR);

    if ( ( ServicePathU.Buffer = (PWCHAR)malloc ( 
        ServicePathU.MaximumLength ) ) == NULL ) {
        printf ( "[-] malloc (%d) FAIL\n", ServicePathU.MaximumLength );
        goto Exit;
    }

    swprintf ( ServicePathU.Buffer, ServicePathU.MaximumLength, L"%hs\\%hs", SERVICES_KEY_A, ServiceName );

    ServicePathU.Length = ServicePathU.MaximumLength - sizeof (WCHAR);

    printf ( "[*] %s %wZ\n", LoadOrUnload ? "Loading" : "Unloading", &ServicePathU );

    if ( ( Result = EnablePrivilege (  SE_LOAD_DRIVER_PRIVILEGE ) ) != ERROR_SUCCESS ) {
        printf ( "[-] EnablePrivilege (SE_LOAD_DRIVER_PRIVILEGE) FAIL=0x%08x\n", Result );
        goto Exit;
    }

    if ( LoadOrUnload ) {
        Status = NtLoadDriverX ( &ServicePathU );
        if ( ! NT_SUCCESS(Status) ) {
            printf ( "[-] NtLoadDriver() FAIL=0x%08x", Status );
        }
    } else {
        Status = NtUnloadDriverX ( &ServicePathU );
        if ( ! NT_SUCCESS(Status) ) {
            printf ( "[-] NtUnloadDriver() FAIL=0x%08x", Status );
        }
    }

Exit :
    if( ServicePathU.Buffer ){
        free ( ServicePathU.Buffer );
    }
    return;
}

ULONG
EnablePrivilege (
    ULONG Privilege )
{
    ULONG Result = ERROR_SUCCESS;
    HANDLE CurrentToken = NULL;
    TOKEN_PRIVILEGES TokenPrivileges;

    if ( OpenThreadToken(GetCurrentThread(), TOKEN_ALL_ACCESS, TRUE, &CurrentToken) != TRUE ) {
        if ( OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &CurrentToken) != TRUE ) {
            Result = GetLastError();
            goto Exit;
        }
    }

    TokenPrivileges.PrivilegeCount = 1;
    TokenPrivileges.Privileges[0].Luid.LowPart = Privilege;
    TokenPrivileges.Privileges[0].Luid.HighPart = 0;
    TokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    if ( ! AdjustTokenPrivileges(
        CurrentToken, 
        FALSE, 
        &TokenPrivileges, 
        0, 
        (PTOKEN_PRIVILEGES)NULL, 
        0 ) ) {

        Result = GetLastError();
        goto Exit;
    }

Exit :
    if ( CurrentToken ) {
        CloseHandle ( CurrentToken );
    }

    return Result;
}

VOID Usage ( VOID )
{
    printf ( "\nusage : LoadDriver [-u] <DriverServiceName>\n" );
}

int _cdecl 
main ( 
    int argc, char *argv[] ) 
{
    BOOL LoadOrUnload = TRUE;
    PCHAR DriverServiceName = NULL;
    int ArgIdx;

    if ( ( argc < 2 ) || ( argc > 3 ) ) {
        Usage();
        goto Exit;
    }

    for ( ArgIdx = 1 ; ArgIdx < argc ; ArgIdx ++ ) {
        if ( strcmp ( argv[ArgIdx], "/?" ) == 0 ) {
            Usage();
            goto Exit;
        } else if ( strcmp ( argv[ArgIdx], "-?" ) == 0 ) {
            Usage();
            goto Exit;
        } else if ( strcmp ( argv[ArgIdx], "-u" ) == 0 ) {
            LoadOrUnload = FALSE;
        } else {
            DriverServiceName = argv[ArgIdx];
        }
    }

    if ( DriverServiceName == NULL ) {
        Usage();
        goto Exit;
    }

    LoadUnloadDriver( DriverServiceName, LoadOrUnload );

Exit :
    return 0;
}